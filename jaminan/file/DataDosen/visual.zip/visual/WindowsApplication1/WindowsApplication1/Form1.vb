﻿Public Class Formsalary

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox4_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox4.LostFocus
        Dim basic As Single 'mendeklarasikan variable basic dengan type data Single
        Dim cut As Single   'mendeklarasikan variable cut dengan type data Single
        Dim alow As Single  'mendeklarasikan variable alow dengan type data Single
        Dim hasil As Single 'mendeklarasikan variable hasil dengan type data Single

        basic = TextBox2.Text 'membaca inputan angka dari textbox2 dengan menggunakan variabel basic
        cut = TextBox3.Text 'membaca inputan angka dari textbox2 dengan menggunakan variabel cut
        alow = TextBox4.Text 'membaca inputan angka dari textbox2 dengan menggunakan variabel alow
        hasil = basic - cut + alow 'mengisi nilai variabel hasil dengan mengkalkulasi variabel basic dikurangi 
        'variabel cut ditambah variabel alow

        TextBox5.Text = hasil 'mengisi textbox5 dengan hasil kalkulasi yang disimpan di variabel hasil

    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        End 'mengakhiri program saat button 2 di klik
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = "" 'membuat isi texbox1 menjadi kosong saat button1 di klik
        TextBox2.Text = ""  'membuat isi texbox2 menjadi kosong saat button1 di klik
        TextBox3.Text = "" 'membuat isi texbox3 menjadi kosong saat button1 di klik
        TextBox4.Text = "" 'membuat isi texbox4 menjadi kosong saat button1 di klik
        TextBox5.Text = "" 'membuat isi texbox4 menjadi kosong saat button1 di klik
    End Sub
End Class
