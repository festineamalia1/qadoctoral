/* 	no komputer : 17
		nama    : norlaili
		nim     : 04082
	*/


# include <iostream>
# include <conio.h>
# include <math.h>

using namespace std;

double f(double x){
       double hasil = pow(x,2)+ sqrt(x)-100;
       return hasil;
       }
       
       double fa(double x){
              double hasil = 2*(x)+ 0.5*(pow(x,-0.5));
              return hasil;
              }

int main(){
    
    double x, toleransi, maxiterasi;
    cout<<" masukan tebakan awalnya adalah :";
    cin>>x;
    cout<<"dengan toleransi nya  maksimal 4 angka di belakang koma:";
    cin>>toleransi;
    cout<<" dan maximum iterasinya mohon masukan kurang dari 100 adalah :";
    cin>>maxiterasi;
    double iterasi=0;
    
   while((fabs(x))>toleransi && iterasi<maxiterasi){
                              x= x-f(f(x)/fa(x));
                              iterasi++;
                              cout<<"hasilnya adalah"<<x<< "dengan eror |f(x)|"<< fabs(f(x))<<"dengan iterasi sebanyak "<<iterasi<< endl; 
                              }
                              

getch();
return 0;
}
