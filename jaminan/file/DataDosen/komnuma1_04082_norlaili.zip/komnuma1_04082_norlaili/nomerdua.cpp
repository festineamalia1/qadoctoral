/* 	no komputer :S 17
		nama    : norlaili
		nim     : 04082
	*/


# include <iostream>
# include <conio.h>
# include <math.h>

using namespace std;

double f(double x){
       double hasil = pow(x,2)+ sqrt(x)-100;
       return hasil;
       }
      
int main(){
    
    double xa,xb,n,i,xi,xii,h;
    cout<<"masukan batas atas  :";
    cin>>xa;
    cout<<"masukan batas bawah  :";
    cin>>xb;
    cout<<" pembagian :";
    cin>>n;
    
    double iterasi=0;
    h = (xa-xb)/n;
    for (int i=0; i=n-1; i++){
        xi = xb + ( i * h );
        xii = xb + (( i+1 )*h );       
	
       if(f(xi)==0){
                 cout<<"hasilnya "<<xi;
                 
            }else if(f(xi) * f(xii) < 0){
                   cout<<"hasilnya " <<xi;
                   cout<<"hasilnya "<<f(xi);
                    }
           }

getch();
return 0;
}

