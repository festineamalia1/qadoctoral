<?php
	if(isset($_POST['login'])) {
		if(isset($_POST['username']) && isset($_POST['password'])) {
			if ($_POST['username'] == 'A' && $_POST['password'] =='1') {
				$login = true;
			}
								
			else {
				$login = false;
				}
		}
	}
?>
								
								
<html>
	<title> Login Page </title>
	<head> 
		<style type="text/css">
			@import url('web1.css');
		</style>
			<center>
		
	
		<?php 
			if(isset($login)) {
					if($login == true)
						echo "Selamat Anda berhasil login!!!";
							else
								echo "Password dan Username yang Anda masukkan salah!!!";
			}
										
		?>
			</center>
	</head>
	
	<body>
	
		<?php
			if(!isset($_POST['username']) && !isset($_POST['password'])) {
				echo "
		<center>
			<p class = 'p1'> Login Site </p>
			<br>
			<br> <table border ='1' cellpadding = '15' color = ' '>
				<tr>
					<td>
						<font = 'Comic Sans MS'> </font>
						<h1> LOGIN </h1> 
							<form id='frmLogin' name='frmLogin' method='POST' action='A1_05087_Tsalis.php'>
								<br> Username	: &nbsp; <input type='text' id='username' name='username'/>
								</br>
								<br>Password	: &nbsp;  <input type='password' id='password' name='password'/>
								</br>
								<br> <center> <input type='submit' id='login' name='login' value='login'/> </center>
								<br> <center> <input type='submit' id='Reset' name='Reset' value='Reset'/> </center>
							
							
								<p> Nama	: Tsalis Restu </p>
								<p> NIM		: 13/SV/355353/05087</P>
								<p> Kelas	: KOMSI-A1 </p>
							</form> 
					</td>
				</tr>
				
			</table>
		</center>
						";
						
			}
			else
				if($login == true)
					echo "
			
		<center>				
			<br> <table border ='1' cellpadding = '15' color = ' '>
				<tr>
					<td>
						<font = 'Comic Sans MS'> </font>
							<form action= ' ' method = 'POST' name='frmHitung' id='frmHitung'>
							
							<br> Angka 1 &nbsp; : &nbsp;
								<input type='text' name='angka1' id = 'angka1' onFocus='startCalc2();' onBlur='stopCalc2();' placeholder='Masukkan angka'>
							</br>
							
							<br> Operator&nbsp; : &nbsp;
								<input type='text' name='operator' id = 'operator' onFocus='startCalc2();' onBlur='stopCalc2();'>
							</br>
							
							<br> Angka 2 &nbsp; : &nbsp;
								<input type='text' name='angka2' id ='angka2' onFocus='startCalc2();' onBlur='stopCalc2();'>
							</br>
		
							<br> Hasil &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : &nbsp;
								<input type='text' name='hasil' id='hasil' readonly>
							</br>
						
							</form>
					</td>
				</tr>
			</table>
		</center>

	
		<script type='text/javascript'>
			function startCalc2() {
				interval = setInterval ('calc2()',1)
			}
			
			function calc2() {
				var vangka1 = eval(document.frmHitung.angka1.value);
				var vangka2 = eval(document.frmHitung.angka2.value);
				var voperator = document.frmHitung.operator.value;
				
				if(voperator == '*') {
					var vhasil = vangka1 * vangka2;
					
				} else if(voperator == '/') {
					var vhasil = vangka1/vangka2;
					
				} else if(voperator == '+') {
					var vhasil = vangka1+vangka2;
					
				} else if(voperator == '-') {
					var vhasil = vangka1-vangka2;
					
				} else vhasil = 'Invalid operator';
				
				document.frmHitung.hasil.value = vhasil;
			}
			
			function stopCalc2() { //stopCalc2 merupakan nama variabel //
				clearInterval (interval)
			}
		</script>
		";
		
		
			else					
				echo "
						<center>
							<br> <table border ='1' cellpadding = '15' color = ' '>
								<tr>
									<td>
										<font = 'Comic Sans MS'> </font>
											<br> Silakan masukkan password dan username Anda dengan benar!!!
												<a href='?'> Back to Login Site? </a>
									</td>
								</tr>
							</table>
						</center>
					
					";
		?>		
	
		<center>
			<p> Copyright &copy; Tsalis 2014 </p>
			
		</center>

		
		 
	</body>
<html>
