/*
No. Komputer : 24
Nama : Festine Amalia P.
Nim :13/354687/SV/04774
*/

#include <iostream>
#include <conio.h>
#include <math.h>

using namespace std;

double f(double x){
       double y = pow(x,2) + pow(x,0.5) - 100;
       return y;
       }
       
       double f_turunan(double x){
              double y = (2*x) + (0.5*pow(x,-0.5));
              return y;
              }
              
              int main(){
                  double x, toler, maxIters;
                  double iters = 0;
                  
                  cout<<"tebakan Awal : ";
                  cin>>x;
                  cout<<"Toleransi : ";
                  cin>>toler;
                  cout<<"Max. Iterasi : ";
                  cin>>maxIters;
                  
                    do{
                                  x = x - (f(x)/ f_turunan(x));
                                  iters = iters + 1;
                                  
                                  }
                                  
                                  while((f(x) > toler) && (iters < maxIters));
                                  cout<<x<<fabs(f(x)) <<"Iterasi Sebanyak"<<iters;
                                  
                                  system ("pause");
                                  return 0;
                                  
                  }
                  
                
                                  
