/*
No. Komputer : 24
Nama : Festine Amalia P.
Nim :13/354687/SV/04774
*/

#include <iostream>
#include <conio.h>
#include <math.h>

using namespace std;
double f(double x){
        double y = pow(x,2) + pow(x,0.5)-100;
        return y;       
               }
               
              
               int main(){
                   double xa, xb, n, x1,x2,h;
                   int iters;
                   cout<<"Batas atas : ";
                   cin>>xa;
                   cout<<"Batas bawah : ";
                   cin>>xb;
                   cout<<"Pembagi : ";
                   cin>>n;
                   
                   for(iters = 0; iters <= n-1; iters++){
                               h = (xa- xb)/n;
                               x1 = xb + (iters*h);
                               x2 = xb + ((iters + 1)*h);
                               
                               if(f(x1) == 0){
                                           cout<<"x1 : "<<x1;
                                           }
                                           else(f(x1)* f(x2) < 0);
                                                cout<<"xi : "<<x1<<"f(xi) : "<<f(x1);
                                                
                               }
                   system("pause");
                   return 0;
                   }
